**Todo**

1) Create GET /notifications route
2) Connect to database 
3) Fetch the notifications 
4) expose in /notification endpoint

5) Create POST /notifications route
6) Create kafka consumer service 
7) Get the payload and save it to DB 
