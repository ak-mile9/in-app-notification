export interface RecordsInterface {
    id?: number;
    title: string;

    user: string;
    for_role: string
    createdAt?: Date;
}
